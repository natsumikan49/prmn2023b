package jp.ac.chitose.db_prac;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class AppTest {

  @Test
  void test() {
    assertEquals(0, 0);
  }
}
